package com.example.apple.prop;

import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.List;
import java.util.Locale;

public class Vendor_showrrom_details extends AppCompatActivity implements LocationListener {

    EditText Area, Location, price, name_of_owner, contact_no_owner;
    DatabaseReference ref;
    FirebaseDatabase fire;
    Button upload, submit;
    private StorageReference mStorageRef;
    ImageView img,img2;
    Uri mg2;
    Show show;

    LocationManager locationManager;

    private static final int IMAGE_PIC_CODE = 1000;
    private static final int PERMISSION_CODE = 1001;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vendor_showrrom_details);

        Area = (EditText) findViewById(R.id.Area_of_showroom);
        Location = (EditText) findViewById(R.id.location_of_showroom);

        price = (EditText) findViewById(R.id.price_of_showroom);
        ref = FirebaseDatabase.getInstance().getReference().child("Show");
        mStorageRef= FirebaseStorage.getInstance().getReference("Images");
        name_of_owner = (EditText) findViewById(R.id.name_of_owner_of_showroom);
        contact_no_owner = (EditText) findViewById(R.id.show_contact_no);

        fire = FirebaseDatabase.getInstance();
        ref = fire.getReference("Godown_users");
        upload = (Button) findViewById(R.id.showroom_pic_upload);
        submit = (Button) findViewById(R.id.submit_of_showroom);
        img = (ImageView) findViewById(R.id.loc_of_show);
        img2=(ImageView)findViewById(R.id.image_of_showroom);
        show=new Show();




        if (ContextCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION}, 101);

        }


        upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (Build.VERSION.SDK_INT > Build.VERSION_CODES.M) {
                    if (checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
                        String[] perm = {android.Manifest.permission.READ_EXTERNAL_STORAGE};
                        requestPermissions(perm, PERMISSION_CODE);
                    } else {
                        savepdf();
                    }
                } else {
                    savepdf();
                }
            }
        });

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addShowroom_users();
            }
        });

        img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getLocation();
            }
        });

    }

    private void addShowroom_users() {

        String area=Area.getText().toString().trim();
        String locaton=Location.getText().toString().trim();
        String tprice=price.getText().toString().trim();
        String name=name_of_owner.getText().toString().trim();
        String num=contact_no_owner.getText().toString().trim();




        if (TextUtils.isEmpty(Area.getText().toString())) {
            Toast.makeText(getApplicationContext(), "enter the area", Toast.LENGTH_LONG).show();
        } else if (TextUtils.isEmpty(Location.getText().toString())) {
            Toast.makeText(getApplicationContext(), "enter the location", Toast.LENGTH_LONG).show();
        } else if (TextUtils.isEmpty(contact_no_owner.getText().toString())) {
            Toast.makeText(getApplicationContext(), "enter the owner number", Toast.LENGTH_LONG).show();
        } else if (TextUtils.isEmpty(name_of_owner.getText().toString())) {
            Toast.makeText(getApplicationContext(), "enter the name of owner", Toast.LENGTH_LONG).show();
        } else if (TextUtils.isEmpty(price.getText().toString())) {
            Toast.makeText(getApplicationContext(), "enter the price", Toast.LENGTH_LONG).show();
        }



      show.setArea(area);
        show.setLocation(locaton);
        show.setContact_no_owner(num);
        show.setName_of_owner(name);
        show.setPrice(tprice);

        Toast.makeText(this, "Added ....", Toast.LENGTH_SHORT).show();



    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        switch (requestCode) {
            case PERMISSION_CODE: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    savepdf();

                } else {
                    Toast.makeText(this, "Permission Denied....", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == RESULT_OK && requestCode == IMAGE_PIC_CODE) {

        }
    }

    private void savepdf() {
        Intent i = new Intent(Intent.ACTION_PICK);
        i.setType("image/*");
        startActivityForResult(i, IMAGE_PIC_CODE);



    }

    void getLocation() {
        try {
            locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 5000, 5, this);
        } catch (SecurityException e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onLocationChanged(android.location.Location location) {
        Location.setText("Latitude: " + location.getLatitude() + "\n Longitude: " + location.getLongitude());

        try {
            Geocoder geocoder = new Geocoder(this, Locale.getDefault());
            List<Address> addresses = geocoder.getFromLocation(location.getLatitude(), location.getLongitude(), 1);
            Location.setText(addresses.get(0).getAddressLine(0));
        }catch(Exception e)
        {

        }

    }

    @Override
    public void onStatusChanged(String s, int i, Bundle bundle) {

    }

    @Override
    public void onProviderEnabled(String s) {

    }

    @Override
    public void onProviderDisabled(String s) {
        Toast.makeText(Vendor_showrrom_details.this, "Please Enable GPS and Internet", Toast.LENGTH_SHORT).show();

    }
}
