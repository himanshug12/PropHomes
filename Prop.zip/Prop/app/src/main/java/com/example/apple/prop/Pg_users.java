package com.example.apple.prop;

/**
 * Created by apple on 03/07/19.
 */

public class Pg_users {

    private String name_of_pg,Area,Location,NearbyAreas,Sharing,price,facilities,name_of_owner,contact_no_owner;

    private String attached_bathroom;
    public Pg_users()
    {

    }
    public Pg_users(String name_of_pg, String area, String location, String nearbyAreas, String sharing, String price, String facilities,  String name_of_owner, String contact_no_owner,String attached_bathroom) {
        this.name_of_pg = name_of_pg;
        Area = area;
        Location = location;
        NearbyAreas = nearbyAreas;
        Sharing = sharing;
        this.price = price;

        this.facilities = facilities;

        this.name_of_owner = name_of_owner;
        this.contact_no_owner = contact_no_owner;
        this.attached_bathroom=attached_bathroom;

    }

    public String getName_of_pg() {
        return name_of_pg;
    }

    public void setName_of_pg(String name_of_pg) {
        this.name_of_pg = name_of_pg;
    }

    public String getArea() {
        return Area;
    }

    public void setArea(String area) {
        Area = area;
    }

    public String getLocation() {
        return Location;
    }

    public void setLocation(String location) {
        Location = location;
    }

    public String getNearbyAreas() {
        return NearbyAreas;
    }

    public void setNearbyAreas(String nearbyAreas) {
        NearbyAreas = nearbyAreas;
    }

    public String getSharing() {
        return Sharing;
    }

    public void setSharing(String sharing) {
        Sharing = sharing;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getFacilities() {
        return facilities;
    }

    public void setFacilities(String facilities) {
        this.facilities = facilities;
    }

    public String getName_of_owner() {
        return name_of_owner;
    }

    public void setName_of_owner(String name_of_owner) {
        this.name_of_owner = name_of_owner;
    }

    public String getContact_no_owner() {
        return contact_no_owner;
    }

    public void setContact_no_owner(String contact_no_owner) {
        this.contact_no_owner = contact_no_owner;
    }

    public String getAttached_bathroom() {
        return attached_bathroom;
    }

    public void setAttached_bathroom(String attached_bathroom) {
        this.attached_bathroom = attached_bathroom;
    }
}
