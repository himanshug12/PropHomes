package com.example.apple.prop;

import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;


public class Client_Home_list extends AppCompatActivity {


        DatabaseReference reference;
        RecyclerView recyclerView;
        ArrayList<Home_users> list;
        yAdapter adapter;
        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_client__home_list);

            recyclerView = (RecyclerView) findViewById(R.id.recycle);
            recyclerView.setLayoutManager( new LinearLayoutManager(this));


            reference = FirebaseDatabase.getInstance().getReference().child("Profiles");
            reference.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    list = new ArrayList<Home_users>();
                    for(DataSnapshot dataSnapshot1: dataSnapshot.getChildren())
                    {
                        Home_users p = dataSnapshot1.getValue(Home_users.class);
                        list.add(p);
                    }
                    adapter = new yAdapter(Client_Home_list.this,list);
                    recyclerView.setAdapter(adapter);
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    Toast.makeText(Client_Home_list.this, "Opsss.... Something is wrong", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
