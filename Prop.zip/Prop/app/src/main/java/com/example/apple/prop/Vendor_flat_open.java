package com.example.apple.prop;

import android.*;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Vendor_flat_open extends AppCompatActivity {
    private RadioButton dioGroup,Group;
    EditText name_of_apartment,Area,Location,NearbyAreas,Status,price,Carpet_area,facilities,facing,name_of_owner,contact_no_owner;
    RadioButton furnished,bhk;
    DatabaseReference ref;
    FirebaseDatabase fire;
    Button upload,submit;
    Flat_users user;

    ImageView img;
    private RadioGroup radioGroup1,radioGroup2;


    private static final int IMAGE_PIC_CODE = 1000;
    private static final int PERMISSION_CODE = 1001;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vendor_flat_open);
        img=(ImageView)findViewById(R.id.image_of_flat);

        name_of_apartment=(EditText)findViewById(R.id.name_of_apartment) ;
        Area=(EditText)findViewById(R.id.flat_area) ;
        Location=(EditText)findViewById(R.id.flat_location) ;
        NearbyAreas=(EditText)findViewById(R.id.flat_nearby) ;
        Status=(EditText)findViewById(R.id.flat_status) ;
        price=(EditText)findViewById(R.id.flat_price) ;
        Carpet_area=(EditText)findViewById(R.id.flat_carpet) ;
        facing=(EditText)findViewById(R.id.flat_facing) ;
        name_of_owner=(EditText)findViewById(R.id.flat_owner) ;
        contact_no_owner=(EditText)findViewById(R.id.flat_owner_num) ;
        facilities=(EditText)findViewById(R.id.flat_facilities);
        fire=FirebaseDatabase.getInstance();
        ref=fire.getReference("Flat_users");
        upload=(Button)findViewById(R.id.upload_flat) ;
        submit=(Button)findViewById(R.id.submit_flat) ;

        user=new Flat_users();



        upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(Build.VERSION.SDK_INT > Build.VERSION_CODES.M)
                {
                    if(checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE)== PackageManager.PERMISSION_DENIED)
                    {
                        String[] perm= { android.Manifest.permission.READ_EXTERNAL_STORAGE };
                        requestPermissions(perm,PERMISSION_CODE);
                    }
                    else
                    {
                        savepdf();
                    }
                }
                else
                {
                    savepdf();
                }
            }
        });


submit.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                getValue();
                ref.child("User").setValue(user);
                Toast.makeText(Vendor_flat_open.this,"data is suuceffullly done",Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }
});




        radioGroup1.clearCheck();

        radioGroup1.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                RadioButton rb = (RadioButton) group.findViewById(checkedId);
                if (null != rb && checkedId > -1) {
                    Toast.makeText(Vendor_flat_open.this, rb.getText(), Toast.LENGTH_SHORT).show();
                }

            }
        });



        if(TextUtils.isEmpty(name_of_apartment.getText().toString()))
        {
            Toast.makeText(getApplicationContext(),"enter the name of apartment",Toast.LENGTH_LONG).show();
        }
        else if(TextUtils.isEmpty(Area.getText().toString()))
        {
            Toast.makeText(getApplicationContext(),"enter the area",Toast.LENGTH_LONG).show();
        }
        else if(TextUtils.isEmpty(Location.getText().toString()))
        {
            Toast.makeText(getApplicationContext(),"enter the location",Toast.LENGTH_LONG).show();
        }
        else if(TextUtils.isEmpty(facilities.getText().toString()))
        {
            Toast.makeText(getApplicationContext(),"enter the facilities",Toast.LENGTH_LONG).show();
        }
        else if(TextUtils.isEmpty(Carpet_area.getText().toString()))
        {
            Toast.makeText(getApplicationContext(),"enter the carpet area",Toast.LENGTH_LONG).show();
        }
        else if(TextUtils.isEmpty(Status.getText().toString()))
        {
            Toast.makeText(getApplicationContext(),"enter the status",Toast.LENGTH_LONG).show();
        }
        else if(TextUtils.isEmpty(bhk.getText().toString()))
        {
            Toast.makeText(getApplicationContext(),"choose one option",Toast.LENGTH_LONG).show();
        }
        else if(TextUtils.isEmpty(facing.getText().toString()))
        {
            Toast.makeText(getApplicationContext(),"enter the facing of flat",Toast.LENGTH_LONG).show();
        }
        else if(TextUtils.isEmpty(contact_no_owner.getText().toString()))
        {
            Toast.makeText(getApplicationContext(),"enter the owner number",Toast.LENGTH_LONG).show();
        }
        else if(TextUtils.isEmpty(name_of_owner.getText().toString()))
        {
            Toast.makeText(getApplicationContext(),"enter the name of owner",Toast.LENGTH_LONG).show();
        }
        else if(TextUtils.isEmpty(NearbyAreas.getText().toString()))
        {
            Toast.makeText(getApplicationContext(),"enter the areas nearby your flat",Toast.LENGTH_LONG).show();
        }
        else if(TextUtils.isEmpty(price.getText().toString()))
        {
            Toast.makeText(getApplicationContext(),"enter the price",Toast.LENGTH_LONG).show();
        }

    }


    private void getValue()
    {


            user.setName_of_apartment(name_of_apartment.getText().toString());
            user.setArea(Area.getText().toString());
            user.setLocation(Location.getText().toString());
            user.setNearbyAreas(NearbyAreas.getText().toString());
            user.setStatus(Status.getText().toString());
            user.setPrice(price.getText().toString());
            user.setCarpet_area(Carpet_area.getText().toString());
            user.setFacing(facing.getText().toString());
            user.setFacilities(facilities.getText().toString());
            user.setName_of_owner(name_of_owner.getText().toString());
            user.setContact_no_owner(contact_no_owner.getText().toString());


            radioGroup1 = (RadioGroup) findViewById(R.id.radioGroup);

            // get selected radio button from radioGroup
            int selectedId = radioGroup1.getCheckedRadioButtonId();

            // find the radiobutton by returned id
            dioGroup = (RadioButton) findViewById(selectedId);

            user.setBhk(dioGroup.getText().toString());


    }



    public void onClear(View v) {
        /* Clears all selected radio buttons to default */
        radioGroup1.clearCheck();
    }

    public void onSubmit(View v) {
        RadioButton rb = (RadioButton) radioGroup1.findViewById(radioGroup1.getCheckedRadioButtonId());
        Toast.makeText(Vendor_flat_open.this, rb.getText(), Toast.LENGTH_SHORT).show();
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        switch (requestCode) {
            case PERMISSION_CODE: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    savepdf();

                } else {
                    Toast.makeText(this, "Permission Denied....", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(resultCode==RESULT_OK && requestCode==IMAGE_PIC_CODE)
        {
            img.setImageURI(data.getData());
        }
    }

    private void savepdf() {
        Intent i=new Intent(Intent.ACTION_PICK);
        i.setType("image/*");
        startActivityForResult(i,IMAGE_PIC_CODE);

    }






}

