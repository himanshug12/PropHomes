package com.example.apple.prop;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Vendor_login extends AppCompatActivity {
    Button submit, login;

        FirebaseAuth mAuth;
        private static final String TAG = "EmailPassword";

        EditText PASS;
        EditText Ema;
        Button reg;
        Button log;
    @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_vendor_login);

            Ema = (EditText) findViewById(R.id.email);
            PASS = (EditText) findViewById(R.id.password);
            reg = (Button) findViewById(R.id.signup);
            log = (Button) findViewById(R.id.signin);
            mAuth= FirebaseAuth.getInstance();

    reg.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(getApplicationContext(), Register.class);
                    startActivity(intent);
                    finish();
                }
            });

            log.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    String usr=Ema.getText().toString().trim();
                    String pass=PASS.getText().toString().trim();


                    if(TextUtils.isEmpty(pass) || TextUtils.isEmpty(usr) )
                    {
                        Toast.makeText(getApplicationContext(), "eNTER THE detail", Toast.LENGTH_SHORT).show();
                    }
                    else {

                        mAuth.signInWithEmailAndPassword(usr, pass)
                                .addOnCompleteListener(Vendor_login.this, new OnCompleteListener<AuthResult>() {
                                    @Override
                                    public void onComplete(@NonNull Task<AuthResult> task) {
                                        if (task.isSuccessful()) {

                                            startActivity(new Intent(getApplicationContext(), Vendor_home_screen.class));
                                            Toast.makeText(getApplicationContext(), "Login succuccessfully", Toast.LENGTH_SHORT).show();
                                        } else {
                                            Log.w(TAG, "createUserWithEmail:failure", task.getException());
                                            Toast.makeText(getApplicationContext(), "Wrong  credentials", Toast.LENGTH_SHORT).show();


                                        }


                                    }
                                });
                    }
                }




            });

        }



    }









