package com.example.apple.prop;

import android.*;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Vendor_pg_details extends AppCompatActivity {
    private RadioGroup radioGroup;
    EditText name_of_pg,Area,Location,NearbyAreas,Sharing,price,facilities,name_of_owner,contact_no_owner;

    DatabaseReference ref;
    FirebaseDatabase fire;
    Button upload,submit;
    Pg_users user;
    CharSequence value;
    ImageView img;

    private static final int IMAGE_PIC_CODE = 1000;
    private static final int PERMISSION_CODE = 1001;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vendor_pg_details);
        img=(ImageView)findViewById(R.id.image_of_pg);

        name_of_pg=(EditText)findViewById(R.id.name_of_pg) ;
        Area=(EditText)findViewById(R.id.area_of_pg) ;
        Location=(EditText)findViewById(R.id.loaction_of_pg) ;
        NearbyAreas=(EditText)findViewById(R.id.nearby_of_pg) ;
        Sharing=(EditText)findViewById(R.id.sharing_of_pg) ;
        price=(EditText)findViewById(R.id.price_of_pg) ;
        name_of_owner=(EditText)findViewById(R.id.owner_of_pg) ;
        contact_no_owner=(EditText)findViewById(R.id.numof_pg) ;
        facilities=(EditText)findViewById(R.id.facilities_of_pg);
        fire=FirebaseDatabase.getInstance();
        ref=fire.getReference("Pg_users");
        upload=(Button)findViewById(R.id.upload_pg_pic) ;
        submit=(Button)findViewById(R.id.submit_pg);
        radioGroup = (RadioGroup) findViewById(R.id.radioGroup3);
        value = (CharSequence) findViewById(radioGroup.getCheckedRadioButtonId());



        user=new Pg_users();







        upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(Build.VERSION.SDK_INT > Build.VERSION_CODES.M)
                {
                    if(checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE)== PackageManager.PERMISSION_DENIED)
                    {
                        String[] perm= { android.Manifest.permission.READ_EXTERNAL_STORAGE };
                        requestPermissions(perm,PERMISSION_CODE);
                    }
                    else
                    {
                        savepdf();
                    }
                }
                else
                {
                    savepdf();
                }
            }
        });






        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ref.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        getValue();
                        ref.child(name_of_pg.getText().toString()).setValue(user);
                        Toast.makeText(Vendor_pg_details.this,"data is suuceffullly done",Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });
            }
        });




        radioGroup.clearCheck();

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                RadioButton rb = (RadioButton) group.findViewById(checkedId);
                if (null != rb && checkedId > -1) {
                    Toast.makeText(Vendor_pg_details.this, rb.getText(), Toast.LENGTH_SHORT).show();
                }

            }
        });



        if(TextUtils.isEmpty(name_of_pg.getText().toString()))
        {
            Toast.makeText(getApplicationContext(),"enter the name of pg",Toast.LENGTH_LONG).show();
        }
        else if(TextUtils.isEmpty(Area.getText().toString()))
        {
            Toast.makeText(getApplicationContext(),"enter the area",Toast.LENGTH_LONG).show();
        }
        else if(TextUtils.isEmpty(Location.getText().toString()))
        {
            Toast.makeText(getApplicationContext(),"enter the location",Toast.LENGTH_LONG).show();
        }
        else if(TextUtils.isEmpty(facilities.getText().toString()))
        {
            Toast.makeText(getApplicationContext(),"enter the facilities",Toast.LENGTH_LONG).show();
        }
        else if(TextUtils.isEmpty(value.toString()))
        {
            Toast.makeText(getApplicationContext(),"choose the option",Toast.LENGTH_LONG).show();
        }

        else if(TextUtils.isEmpty(Sharing.getText().toString()))
        {
            Toast.makeText(getApplicationContext(),"enter the sharing",Toast.LENGTH_LONG).show();
        }
       else if(TextUtils.isEmpty(contact_no_owner.getText().toString()))
        {
            Toast.makeText(getApplicationContext(),"enter the owner number",Toast.LENGTH_LONG).show();
        }
        else if(TextUtils.isEmpty(name_of_owner.getText().toString()))
        {
            Toast.makeText(getApplicationContext(),"enter the name of owner",Toast.LENGTH_LONG).show();
        }
        else if(TextUtils.isEmpty(NearbyAreas.getText().toString()))
        {
            Toast.makeText(getApplicationContext(),"enter the areas nearby your flat",Toast.LENGTH_LONG).show();
        }
        else if(TextUtils.isEmpty(price.getText().toString()))
        {
            Toast.makeText(getApplicationContext(),"enter the price",Toast.LENGTH_LONG).show();
        }

    }

    private void getValue()
    {
        user.setName_of_pg(name_of_pg.getText().toString());
        user.setArea(Area.getText().toString());
        user.setLocation(Location.getText().toString());
        user.setNearbyAreas(NearbyAreas.getText().toString());
        user.setSharing(Sharing.getText().toString());
        user.setPrice(price.getText().toString());

        user.setFacilities(facilities.getText().toString());
        user.setName_of_owner(name_of_owner.getText().toString());
        user.setContact_no_owner(contact_no_owner.getText().toString());
        user.setAttached_bathroom(value.toString());


    }



    public void onClear(View v) {

        radioGroup.clearCheck();
    }

    public void onSubmit(View v) {
        RadioButton rb = (RadioButton) radioGroup.findViewById(radioGroup.getCheckedRadioButtonId());
        Toast.makeText(Vendor_pg_details.this, rb.getText(), Toast.LENGTH_SHORT).show();
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        switch (requestCode) {
            case PERMISSION_CODE: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    savepdf();

                } else {
                    Toast.makeText(this, "Permission Denied....", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(resultCode==RESULT_OK && requestCode==IMAGE_PIC_CODE)
        {
            img.setImageURI(data.getData());
        }
    }

    private void savepdf() {
        Intent i=new Intent(Intent.ACTION_PICK);
        i.setType("image/*");
        startActivityForResult(i,IMAGE_PIC_CODE);

    }


}

