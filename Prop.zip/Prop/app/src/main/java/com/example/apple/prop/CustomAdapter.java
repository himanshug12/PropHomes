package com.example.apple.prop;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class CustomAdapter extends BaseAdapter {

    // Declare Variables
    Context context;
    String[] name;
    String[] desc;
    String[] rating;
    int[] images;
    LayoutInflater inflater;

    public CustomAdapter(Context context, String[] name, String[] desc,
                         String[] rating, int[] images) {
        this.context = context;
        this.name = name;
        this.desc = desc;
        this.rating = rating;
        this.images = images;
    }

    @Override
    public int getCount() {
        return name.length;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    public View getView(int position, View convertView, ViewGroup parent) {

        // Declare Variables
        TextView txtrank;
        TextView txtcountry;
        TextView txtpopulation;
        ImageView imgflag;

        inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View itemView = inflater.inflate(R.layout.row_lay, parent, false);

        // Locate the TextViews in listview_item.xml
        txtrank = (TextView) itemView.findViewById(R.id.txt1);
        txtcountry = (TextView) itemView.findViewById(R.id.address);
        txtpopulation = (TextView) itemView.findViewById(R.id.marks);
        // Locate the ImageView in listview_item.xml
        imgflag = (ImageView) itemView.findViewById(R.id.img_oflist);

        // Capture position and set to the TextViews
        txtrank.setText(name[position]);
        txtcountry.setText(desc[position]);
        txtpopulation.setText(rating[position]);

        // Capture position and set to the ImageView
        imgflag.setImageResource(images[position]);

        return itemView;
    }
}
