package com.example.apple.prop;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Vendor_land_open extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vendor_land_open);
    }
}
