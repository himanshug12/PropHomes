package com.example.apple.prop;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

public class ReAdapter extends RecyclerView.Adapter<ReAdapter.MyViewHolder>{

    private String[] data;
    private String [] des;


    public ReAdapter(String[] data,String [] des) {
        data=this.data;
        des=this.des;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater=LayoutInflater.from(parent.getContext());
        View view=layoutInflater.inflate(R.layout.row_lay,parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        String title=data[position];
        String desk=des[position];
        holder.txt.setText(title);
        holder.txt2.setText(desk);

    }

    @Override
    public int getItemCount() {
        return 5;

    }

    public  class MyViewHolder extends RecyclerView.ViewHolder{
        ImageView img;
        TextView txt;
        TextView txt2;

        public MyViewHolder(View itemView) {
            super(itemView);
            img=itemView.findViewById(R.id.img_oflist);
            txt=itemView.findViewById(R.id.txt1);
            txt2=itemView.findViewById(R.id.address);
        }
    }


}