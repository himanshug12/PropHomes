package com.example.apple.prop;

/**
 * Created by apple on 08/07/19.
 */

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class yAdapter extends RecyclerView.Adapter<yAdapter.MyViewHolder> {

    Context context;
    ArrayList<Home_users> profiles;

    public yAdapter(Context c , ArrayList<Home_users> p)
    {
        context = c;
        profiles = p;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(context).inflate(R.layout.row_lay,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.name.setText(profiles.get(position).getName_of_home());
        holder.address.setText(profiles.get(position).getArea());
        Picasso.with(context).load(profiles.get(position).getImage()).into(holder.profilePic);


    }

    @Override
    public int getItemCount() {
        return profiles.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder
    {
        TextView name,address;
        ImageView profilePic;

        public MyViewHolder(View itemView) {
            super(itemView);
            name = (TextView) itemView.findViewById(R.id.txt1);
            address = (TextView) itemView.findViewById(R.id.address);
            profilePic = (ImageView) itemView.findViewById(R.id.img_oflist);

        }

    }
}