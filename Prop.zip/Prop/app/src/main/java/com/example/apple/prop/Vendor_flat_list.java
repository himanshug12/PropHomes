package com.example.apple.prop;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Vendor_flat_list extends AppCompatActivity {
    Button back;

    String[]  listviewTitle = new String []{
            "Shree Sai Blaji Pg", "Trinity House", "Teja Pg", "Shri Manjunath ",
            "Delta House ", "Raju Pg for Gents"
    };
    int[] listviewImage = new int[]{
            R.drawable.p1, R.drawable.p2, R.drawable.p3,
            R.drawable.p1, R.drawable.p7, R.drawable.p6
    };
    String[] listviewShortDescription = new String[]{
            "Industrial Estate", "Whitefield", "Brookfield", "Andhra",
            "Marine Drive", "Mg Road"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vendor_flat_list);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        List<HashMap<String, String>> aList = new ArrayList<HashMap<String, String>>();
        HashMap<String, String> hm = new HashMap<String, String>();

        for (int i = 0; i < 6; i++) {

            hm.put("listview_title", listviewTitle[i]);
            hm.put("listview_discription", listviewShortDescription[i]);
            hm.put("listview_image", Integer.toString(listviewImage[i]));
            aList.add(hm);
        }





        String[] from = {"listview_image", "listview_title", "listview_discription"};
        int[] to = {R.id.img_oflist, R.id.txt1, R.id.address};

        SimpleAdapter simpleAdapter = new SimpleAdapter(getBaseContext(), aList, R.layout.row_lay, from, to);
        ListView androidListView = (ListView) findViewById(R.id.list);
        androidListView.setAdapter(simpleAdapter);
        // Item Click Listener for the listview
        AdapterView.OnItemClickListener itemClickListener = new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View container, int position, long id) {
                // Getting the Container Layout of the ListView
                LinearLayout linearLayoutParent = (LinearLayout) container;

                // Getting the inner Linear Layout
                LinearLayout linearLayoutChild = (LinearLayout ) linearLayoutParent.getChildAt(1);

                // Getting the Country TextView
                TextView tvCountry = (TextView) linearLayoutChild.getChildAt(0);

                Toast.makeText(getBaseContext(), tvCountry.getText().toString(), Toast.LENGTH_SHORT).show();
            }
        };






        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              Intent intent=new Intent(getApplicationContext(),Vendor_flat_open.class);
              startActivity(intent);
              finish();
            }
        });
    }

}
