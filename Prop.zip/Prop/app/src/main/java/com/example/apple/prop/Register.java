package com.example.apple.prop;


import android.content.Intent;

import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.FirebaseDatabase;

public class Register extends AppCompatActivity {

   FirebaseAuth mAuth;
    private static final String TAG = "EmailPassword";
    EditText user;
    EditText PASS;
    EditText MOB;
    EditText Ema;
    Button reg;
    Button log;
    private RadioGroup radioGroup;

@Override
    protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_register);

    mAuth = FirebaseAuth.getInstance();
    user = (EditText) findViewById(R.id.name_of_client);
    PASS = (EditText) findViewById(R.id.password_of_client);
    MOB = (EditText) findViewById(R.id.contact_no_of_client);
    Ema = (EditText) findViewById(R.id.email_of_client);
    reg = (Button) findViewById(R.id.register);
    log = (Button) findViewById(R.id.login);

    radioGroup = (RadioGroup) findViewById(R.id.radioGroup_register);
    radioGroup.clearCheck();


    log.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Intent intent = new Intent(getApplicationContext(), Login.class);
            startActivity(intent);
            finish();
        }
    });

    reg.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {

            final String name = user.getText().toString().trim();
            String pass = PASS.getText().toString().trim();
            final String mob = MOB.getText().toString().trim();
            final String ema = Ema.getText().toString().trim();


            if (TextUtils.isEmpty(name) || TextUtils.isEmpty(pass) || TextUtils.isEmpty(ema) || TextUtils.isEmpty(mob)) {
                Toast.makeText(getApplicationContext(), "eNTER THE detail", Toast.LENGTH_SHORT).show();
            } else {

                mAuth.createUserWithEmailAndPassword(ema, pass)
                        .addOnCompleteListener(Register.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull final Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    User used = new User(name, mob, ema);
                                    FirebaseDatabase.getInstance().getReference("Users").
                                            child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                            .setValue(used).addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {

                                            if (task.isSuccessful()) {

                                                Toast.makeText(getApplicationContext(), "successfull", Toast.LENGTH_SHORT).show();
                                            }

                                        }
                                    });
                                    radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(RadioGroup group, int checkedId) {
                                            RadioButton rb = (RadioButton) group.findViewById(checkedId);
                                            if (null != rb && checkedId > -1) {


                                                Toast.makeText(getApplicationContext(), "Register succuccessfully", Toast.LENGTH_SHORT).show();


                                            } else {
                                                Log.w(TAG, "createUserWithEmail:failure", task.getException());
                                                Toast.makeText(getApplicationContext(), "Authentication Failed", Toast.LENGTH_SHORT).show();


                                            }


                                        }
                                    });
                                }
                            }


                        });


            }
        }
    });
}

            public void onClear(View v) {
        /* Clears all selected radio buttons to default */
                radioGroup.clearCheck();
            }

            public void onSubmit(View v) {
                RadioButton rb = (RadioButton) radioGroup.findViewById(radioGroup.getCheckedRadioButtonId());

            }


        }




