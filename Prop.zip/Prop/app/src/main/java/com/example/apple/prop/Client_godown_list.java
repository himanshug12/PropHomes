package com.example.apple.prop;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Client_godown_list extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_client_godown_list);
    }
}
