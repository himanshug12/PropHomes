package com.example.apple.prop;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

public class Client_flat_list extends AppCompatActivity {

    ListView list;
    CustomAdapter adapter;
    String[] name_of_thing;
    String[] des_of_thing;
    String[] rating;
    int[] image;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_client_flat_list);

        // Generate sample data into string arrays
        name_of_thing = new String[]{"Trojan Flat", "Navjeevan Apartment", "Shri Bhaktikunj Flat", "Shree Balaji Apartment", "Avahan Flats"};

        des_of_thing = new String[]{"WhiteField", "BrookField", "Hoodi",
                "Andhra", "Industrial Estate"};

        rating = new String[]{"4.2", "3.8",
                "4.9", "3.7", "3.6"};

        image = new int[]{R.drawable.flat_3, R.drawable.flat_1,
                R.drawable.flat_2, R.drawable.flat_4,
                R.drawable.flat_5};

        // Locate the ListView in listview_main.xml
        list = (ListView) findViewById(R.id.list);

        // Pass results to ListViewAdapter Class
        adapter = new CustomAdapter(this, name_of_thing, des_of_thing, rating, image);
        // Binds the Adapter to the ListView
        list.setAdapter(adapter);


        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                if (position == 0) {
                    Intent myIntent = new Intent(view.getContext(), Vendor_flat_list_open_first.class);
                    startActivityForResult(myIntent, 0);
                }
                if (position == 1) {
                    Intent myIntent = new Intent(view.getContext(), Vendor_flat_list_open_first.class);
                    startActivityForResult(myIntent, 0);
                }

                if (position == 2) {
                    Intent myIntent = new Intent(view.getContext(), Vendor_flat_list_open_first.class);
                    startActivityForResult(myIntent, 0);
                }

                if (position == 3) {
                    Intent myIntent = new Intent(view.getContext(), Vendor_flat_list_open_first.class);
                    startActivityForResult(myIntent, 0);
                }

                if (position == 4) {
                    Intent myIntent = new Intent(view.getContext(), Vendor_flat_list_open_first.class);
                    startActivityForResult(myIntent, 0);
                }


            }
        });
    }
}
