package com.example.apple.prop;

/**
 * Created by apple on 08/07/19.
 */

public class Home_users {
    private String name_of_home,no_of_rooms,Area,Location,NearbyAreas,No_of_bathrooms,price,facilities,furnished,name_of_owner,contact_no_owner,image;

    public Home_users() {
    }



    public Home_users(String name_of_home, String no_of_rooms, String area, String location, String nearbyAreas, String no_of_bathrooms, String image, String price, String facilities, String furnished, String name_of_owner, String contact_no_owner) {
        this.name_of_home = name_of_home;
        this.no_of_rooms = no_of_rooms;
        Area = area;
        Location = location;
        NearbyAreas = nearbyAreas;
        No_of_bathrooms = no_of_bathrooms;
        this.price = price;
        this.facilities = facilities;
        this.furnished = furnished;
        this.name_of_owner = name_of_owner;
        this.contact_no_owner = contact_no_owner;
        this.image=image;
    }

    public String getName_of_home() {
        return name_of_home;
    }

    public void setName_of_home(String name_of_home) {
        this.name_of_home = name_of_home;
    }

    public String getNo_of_rooms() {
        return no_of_rooms;
    }

    public void setNo_of_rooms(String no_of_rooms) {
        this.no_of_rooms = no_of_rooms;
    }

    public String getArea() {
        return Area;
    }

    public void setArea(String area) {
        Area = area;
    }

    public String getLocation() {
        return Location;
    }

    public void setLocation(String location) {
        Location = location;
    }

    public String getNearbyAreas() {
        return NearbyAreas;
    }

    public void setNearbyAreas(String nearbyAreas) {
        NearbyAreas = nearbyAreas;
    }

    public String getNo_of_bathrooms() {
        return No_of_bathrooms;
    }

    public void setNo_of_bathrooms(String no_of_bathrooms) {
        No_of_bathrooms = no_of_bathrooms;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getFacilities() {
        return facilities;
    }

    public void setFacilities(String facilities) {
        this.facilities = facilities;
    }

    public String getFurnished() {
        return furnished;
    }

    public void setFurnished(String furnished) {
        this.furnished = furnished;
    }

    public String getName_of_owner() {
        return name_of_owner;
    }

    public void setName_of_owner(String name_of_owner) {
        this.name_of_owner = name_of_owner;
    }

    public String getContact_no_owner() {
        return contact_no_owner;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public void setContact_no_owner(String contact_no_owner) {
        this.contact_no_owner = contact_no_owner;
    }
}
