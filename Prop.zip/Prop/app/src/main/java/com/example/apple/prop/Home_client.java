package com.example.apple.prop;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


public class Home_client extends AppCompatActivity {

    String[] listviewTitle = new String[]{
            "Shree Sai Blaji Pg", "Trinity House", "Teja Pg", "Shri Manjunath ",
            "Delta House ", "Raju Pg for Gents"
    };
    int[] listviewImage = new int[]{
            R.drawable.p1, R.drawable.p2, R.drawable.p3,
            R.drawable.p1, R.drawable.p7, R.drawable.p6
    };
    String[] listviewShortDescription = new String[]{
            "Industrial Estate", "Whitefield", "Brookfield", "Andhra",
            "Marine Drive", "Mg Road"
    };



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_client);

        RecyclerView pl=(RecyclerView)findViewById(R.id.list);
        pl.setLayoutManager(new LinearLayoutManager(this));
        pl.setAdapter(new ReAdapter(listviewTitle,listviewShortDescription));
    }
}


