package com.example.apple.prop;

import android.widget.Button;

/**
 * Created by apple on 03/07/19.
 */

public class Flat_users {
    private String name_of_apartment,Area,Location,NearbyAreas,Status,price,Carpet_area,facilities,facing,name_of_owner,contact_no_owner;

     private String bhk,furnished;
public Flat_users()
{

}
    public Flat_users(String name_of_apartment, String area, String location, String nearbyAreas, String status, String price, String carpet_area, String facilities, String facing, String name_of_owner, String contact_no_owner,String bhk,String furnished) {
        this.name_of_apartment = name_of_apartment;
        Area = area;
        Location = location;
        NearbyAreas = nearbyAreas;
        Status = status;
        this.price = price;
        Carpet_area = carpet_area;
        this.facilities = facilities;
        this.facing = facing;
        this.name_of_owner = name_of_owner;
        this.contact_no_owner = contact_no_owner;
        this.bhk=bhk;
        this.furnished=furnished;
    }

    public String getName_of_apartment() {
        return name_of_apartment;
    }

    public void setName_of_apartment(String name_of_apartment) {
        this.name_of_apartment = name_of_apartment;
    }

    public String getArea() {
        return Area;
    }

    public String getBhk() {
        return bhk;
    }

    public String getFurnished() {
        return furnished;
    }



    public void setArea(String area) {
        Area = area;
    }

    public String getLocation() {
        return Location;
    }

    public void setLocation(String location) {
        Location = location;
    }

    public String getNearbyAreas() {
        return NearbyAreas;
    }

    public void setNearbyAreas(String nearbyAreas) {
        NearbyAreas = nearbyAreas;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        Status = status;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getCarpet_area() {
        return Carpet_area;
    }

    public void setCarpet_area(String carpet_area) {
        Carpet_area = carpet_area;
    }

    public String getFacilities(String bhk) {
        return facilities;
    }
    public void setBhk(String s) { this.bhk= bhk;}

    public void setFurnished(String s) {
        this.furnished= furnished;}

    public void setFacilities(String facilities) {
        this.facilities = facilities;
    }

    public String getFacing() {
        return facing;
    }

    public void setFacing(String facing) {
        this.facing = facing;
    }

    public String getName_of_owner() {
        return name_of_owner;
    }

    public void setName_of_owner(String name_of_owner) {
        this.name_of_owner = name_of_owner;
    }

    public String getContact_no_owner() {
        return contact_no_owner;
    }

    public void setContact_no_owner(String contact_no_owner) {
        this.contact_no_owner = contact_no_owner;
    }
}
