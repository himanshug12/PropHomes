package com.example.apple.prop;

/**
 * Created by apple on 03/07/19.
 */

public class Godown_users {

    public Godown_users(String area, String location, String price, String carpet_area,String name_of_owner, String contact_no_owner) {

        Area = area;
        Location = location;
        this.price = price;
        Carpet_area = carpet_area;
        this.name_of_owner = name_of_owner;
        this.contact_no_owner=contact_no_owner;

    }

    public String getArea() {
        return Area;
    }

    public void setArea(String area) {
        Area = area;
    }

    public String getLocation() {
        return Location;
    }

    public void setLocation(String location) {
        Location = location;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getCarpet_area() {
        return Carpet_area;
    }

    public void setCarpet_area(String carpet_area) {
        Carpet_area = carpet_area;
    }

    public String getName_of_owner() {
        return name_of_owner;
    }

    public void setName_of_owner(String name_of_owner) {
        this.name_of_owner = name_of_owner;
    }

    public String getContact_no_owner() {
        return contact_no_owner;
    }

    public void setContact_no_owner(String contact_no_owner) {
        this.contact_no_owner = contact_no_owner;
    }

    private String Area,Location,price,Carpet_area,name_of_owner,contact_no_owner;


    public Godown_users()
    {

    }




}

