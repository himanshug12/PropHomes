package com.example.apple.prop;

/**
 * Created by apple on 08/07/19.
 */

public class Show {
    private String Area,Location,price,name_of_owner,contact_no_owner,i,imageid;


public Show()
{

}

    public Show(String id, String area, String location, String price, String name_of_owner, String contact_no_owner, String image) {

            Area = area;
            Location = location;
            this.price = price;
            this.i=id;

            this.name_of_owner = name_of_owner;
            this.contact_no_owner=contact_no_owner;
            imageid=image;

        }

    public String getArea() {
        return Area;
    }

    public void setArea(String area) {
        Area = area;
    }

    public String getLocation() {
        return Location;
    }

    public void setLocation(String location) {
        Location = location;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getName_of_owner() {
        return name_of_owner;
    }

    public void setName_of_owner(String name_of_owner) {
        this.name_of_owner = name_of_owner;
    }

    public String getContact_no_owner() {
        return contact_no_owner;
    }

    public void setContact_no_owner(String contact_no_owner) {
        this.contact_no_owner = contact_no_owner;
    }

    public String getI() {
        return i;
    }

    public void setI(String i) {
        this.i = i;
    }
    public String getImageid() {
        return imageid;
    }

    public void setImageid(String imageid) {
        this.imageid = imageid;
    }
}
