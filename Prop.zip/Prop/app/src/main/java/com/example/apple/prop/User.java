package com.example.apple.prop;

/**
 * Created by apple on 02/07/19.
 */

public class User {

    public String name_t;
    public String Contact;
    public String  emailid;


    public  User()
    {


    }
    public User(String name_t, String contact, String emailid) {
        this.name_t = name_t;
        Contact = contact;
        this.emailid = emailid;
    }
}
