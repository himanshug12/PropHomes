package com.example.apple.prop;

/**
 * Created by apple on 04/07/19.
 */


import com.google.android.gms.maps.model.LatLng;

import java.util.ArrayList;
import java.util.List;


public interface Direction {
    void onDirectionFinderStart();
    void onDirectionFinderSuccess(List<Route> route);
}