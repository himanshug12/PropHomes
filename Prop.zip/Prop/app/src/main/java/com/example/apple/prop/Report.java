package com.example.apple.prop;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

public class Report extends AppCompatActivity {
    Button send, back;
    EditText edt1;
    ProgressBar pb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report);
        send = findViewById(R.id.send);
        back = findViewById(R.id.back);
        edt1 = findViewById(R.id.edt);
        pb = findViewById(R.id.progress_bar);
        pb.setVisibility(View.GONE);

        send.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
                                        Intent i = new Intent(getBaseContext(), Vendor_flat_list_open_first.class);

                                        startActivity(i);


                                    }
                                });




        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String report = edt1.getText().toString();
                if (report.length() == 0) {
                    edt1.setError("Enter the problem");
                    edt1.requestFocus();
                } else {
                    Toast.makeText(getApplicationContext(), "SENT", Toast.LENGTH_SHORT).show();

                    Thread thread = new Thread() {
                        @Override
                        public void run() {
                            super.run();
                            try {
                                pb.setVisibility(View.VISIBLE);
                                sleep(5 * 1000);
                                Intent i = new Intent(getBaseContext(), Vendor_flat_list_open_first.class);
                                pb.setVisibility(View.GONE);
                                startActivity(i);


                                finish();
                            } catch (
                                    Exception e)

                            {
                                e.printStackTrace();

                            }
                        }
                    };

                    thread.start();
                }
            }
        });
    }
}
