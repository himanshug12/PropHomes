package com.example.apple.prop;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class Vendor_flat_list_open_first extends AppCompatActivity {

    Button btn,direct;
    TextView CALLNUM,rep;
    Button text,share;
    static int Request_call=1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vendor_flat_list_open_first);
        btn=(Button)findViewById(R.id.make_call);
        CALLNUM=(TextView)findViewById(R.id.number);
        text=(Button)findViewById(R.id.mess);
        share=(Button)findViewById(R.id.shared);
        direct=(Button)findViewById(R.id.direct);
        direct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(Vendor_flat_list_open_first.this,MapsActivity.class);
                startActivity(i);
                finish();
            }
        });



        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                shared();
            }
        });

        text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ping();
            }
        });

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                makecall();
            }
        });
    }

    private void shared() {

        Intent intent =new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        String body="Checkout this ausome property";
        String sub="Checkout";
        intent.putExtra(Intent.EXTRA_SUBJECT,sub);
        intent.putExtra(Intent.EXTRA_TEXT,body);
        startActivity(Intent.createChooser(intent,"Share using"));

    }

    private void ping() {
        String numb=CALLNUM.getText().toString().trim();
        if(CALLNUM.length()>0)
        {

                String dial="smsto:" + numb;
                startActivity(new Intent(Intent.ACTION_SENDTO,Uri.parse(dial)));

            }

        else
            Toast.makeText(this,"Something Went wrong",Toast.LENGTH_SHORT).show();
    }



    private void makecall() {

        String numb=CALLNUM.getText().toString().trim();

        if(CALLNUM.length()>0)
        {
            if(ContextCompat.checkSelfPermission(Vendor_flat_list_open_first.this, Manifest.permission.CALL_PHONE)!= PackageManager.PERMISSION_GRANTED)
            {
                ActivityCompat.requestPermissions(Vendor_flat_list_open_first.this,new String[]{Manifest.permission.CALL_PHONE},Request_call);

            }
            else
            {
                String dial="tel:" + numb;
                startActivity(new Intent(Intent.ACTION_CALL, Uri.parse(dial)));
            }
        }
        else
            Toast.makeText(this,"Something Went wrong",Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
     if(requestCode==Request_call)
     {
         if(grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED)
         {
             makecall();
         }
         else
         {
             Toast.makeText(this,"Permission denied ",Toast.LENGTH_SHORT).show();
         }
     }
    }
}
