package com.example.apple.prop;

/**
 * Created by apple on 04/07/19.
 */

public class Duration {
    public String text;
    public int value;

    public Duration(String text, int value) {
        this.text = text;
        this.value = value;
    }
}